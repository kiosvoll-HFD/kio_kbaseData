
select * from sysobjects order by crdate desc
select * from sysobjects where name like '%06913%'order by crdate desc

select *from SSB_tab06913_Folkemengd_20170829_SAMLA


select substring(geo,1,charindex(' ',geo)) geonr, ltrim(rtrim(substring(geo,charindex(' ',geo),200) ))as GeoNamn,
		substring(attributt,6,100) as variabel, substring(attributt,1,4) as aar, 
		converT(float,replacE(verdi,',','.')) as verdi into #t
		   from imp_SSB_06913_SAMLA_til_SQL_20190904





update #t set geonr = 47,geoNamn = 'Norge' where  geonr like  '0 %' and GeoNamn like '%Hele landet%'

update #t set variabel = 'Folkemengde' where variabel = 'Befolkning'

-- select *from SSB_tab06913_Folkemengd_20170829_SAMLA
-- fjernar dei som ikkje har data 
select distinct geonr as STOPP_geonr into #stopp_geonr from #t a where not exists (select *from #t b where b.geonr = a.geonr and verdi <> 0 ) 
delete #t 
where exists (select * from #stopp_geonr stopp where stopp.stopp_geonr = #t.geonr)
-- 46080



select distinct variabel from SSB_tab06913_Folkemengd_20170829_SAMLA
except 
select variabel from #t 




select *from  ( 
select 'old' kilde,geo as geonr,variabel,aar,verdi from SSB_tab06913_Folkemengd_20170829_SAMLA
except 
select 'old',geonr,variabel,aar,verdi from #t 
union 
select 'new',geonr,variabel,aar,verdi from #t 
except 
select 'new',geo,variabel,aar,verdi from SSB_tab06913_Folkemengd_20170829_SAMLA
) a
where aar between 2005 and 2016
and geonr not like '50%'
order by geonr,variabel,aar 


 select * into SSB_tab06913_Folkemengd_20190904_SAMLA  from #t

 /* 
     drop table  ##SSB_tab06913_tilKontroll
     select geo as geonr, geonamn, variabel, aar,verdi   into ##SSB_tab06913_tilKontroll   from SSB_tab06913_Folkemengd_20170829_SAMLA
*/
  [dbo].[dwdoc_ssb_sjekk_SSB_TAB06913_kalkuleringsfeil]
  /*
	drop table  ##SSB_tab06913_tilKontroll
  select  geonr, geonamn, variabel, aar,verdi   into ##SSB_tab06913_tilKontroll   from SSB_tab06913_Folkemengd_20190904_SAMLA
  */
 [dbo].[dwdoc_ssb_sjekk_SSB_TAB06913_kalkuleringsfeil]



 select * from SSB_tab06913_Folkemengd_20190904_SAMLA where geonr = '1431'  and aar = 2010




