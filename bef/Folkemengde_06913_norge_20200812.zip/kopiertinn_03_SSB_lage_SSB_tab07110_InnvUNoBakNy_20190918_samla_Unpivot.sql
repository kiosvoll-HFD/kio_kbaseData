select * from sysobjects order by crdate desc

 select * from imp_SSB_tab07110_InnvUNoBakNy_20190918


select ltrim(rtrim(substring(geog,1,charindex(' ',geog)) )) as geonr ,
		ltrim(rtrim(substring(geog,charindex(' ',geog),200) )) as geoNamn,
		'Invandrere'as variabel,
		attributt as aar,convert(float,verdi) as verdi into  #nye  from imp_SSB_tab07110_InnvUNoBakNy_20190918

select * from #nye 
update #nye set geonr = '47' where geonr = '0' 

drop table    SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot
select * into SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot from #nye 

select * from SSB_tab07110_InnvUNoBakNy_20170908_samla_Unpivot



-- select * from #tab
 select * from SSB_tab09588_FlyttInnUtNetto_20170825_unpivot


select *From (
select 'i nye' kommentar, geonr,aar,verdi from SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot
except 
select 'i nye', geonr,aar,verdi from SSB_tab07110_InnvUNoBakNy_20170908_samla_Unpivot
union 
select 'i gammle', geonr,aar,verdi from SSB_tab07110_InnvUNoBakNy_20170908_samla_Unpivot
except 
select 'i gammle', geonr,aar,verdi from SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot
) a where aar not in ('2018','2019')order by geonr,aar,kommentar





