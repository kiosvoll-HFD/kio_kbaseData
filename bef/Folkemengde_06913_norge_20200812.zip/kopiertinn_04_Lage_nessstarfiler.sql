/*select * from sysobjects order by crdate desc

select top 1 * from SSB_tab06913_Folkemengd_20190904_SAMLA --- SSB_tab06913_Folkemengd_20170829_SAMLA 
select top 1 * from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot --SSB_tab09588_FlyttInnUtNetto_20170825_unpivot
select top 1 * from SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot  -- SSB_tab07110_InnvUNoBakNy_20170908_samla_Unpivot

 --- SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot


*/
--select distinct variabel from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot

--select * from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot where aar between 2010 and 2016 and geonr is not null
--and variabel in (   'Nettoinnflytting per 1 000 middelfolkemengde',
--					'Innflytting, innenlands',
--					'Utflytting',
--					'Utflytting, innenlands',
--					'Nettoinnflytting',
--					'Innvandring',
--					'Utvandring',
--					'Innenlandsk nettoinnflytting per 1 000 middelfolkemengde',
--					'Nettoinnvandring',
--					'Netto inn- og utvandring per 1 000 middelfolkemengde',
--					'Innflytting',
--					'Nettoinnflytting, innenlands')

--select distinct variabel from SSB_tab06913_Folkemengd_20190904_SAMLA where aar between 2010 and 2016
--and variabel in ('D�de','Folkemengde','Levendef�dte','F�dselsoverskudd','Folketilvekst')


--- BASERT P� DENNE INFOEN UNDER S� JUIster  aar between lenger nede. 

select variabel,aar,sum(verdi) from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot group by variabel,aar  order by aar desc,variabel
select variabel,aar,sum(verdi) from SSB_tab06913_Folkemengd_20190904_SAMLA group by variabel,aar  order by aar desc,variabel
select variabel,aar,sum(verdi) from SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot group by variabel,aar  order by aar desc,variabel

-- drop table #tab
select * into #tab  from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot 
		where aar between 2005 and 2018 and geonr is not null
			and variabel in (  
				 'Nettoinnflytting per 1 000 middelfolkemengde'
				,'Innflytting, innenlands'
				,'Utflytting'
				,'Utflytting, innenlands'
				,'Nettoinnflytting'
				,'Innvandring'
				,'Utvandring'
			    ,'Innenlandsk nettoinnflytting per 1 000 middelfolkemengde'
				,'Nettoinnvandring'
				,'Netto inn- og utvandring per 1 000 middelfolkemengde'
				,'Innflytting'
				,'Nettoinnflytting, innenlands'
				)

union select * from SSB_tab06913_Folkemengd_20190904_SAMLA 
			where aar between 2005 and 2018
				and variabel in ('D�de'
						,'Folkemengde'
						,'Levendef�dte'
						,'F�dselsoverskudd'
						,'Folketilvekst'
						)
union select * from SSB_tab07110_InnvUNoBakNy_20190918_samla_Unpivot
			where aar between 2005 and 2019 


select distinct ',''' + variabel +'''' from #tab

update #tab set verdi = (select verdi from #tab b where b.aar = #tab.aar and b.geoNr = #tab.geoNr and b.variabel = 'Innvandring')  
from #tab where geonr = '47' and variabel = 'Innflytting'
update #tab set verdi = (select verdi from #tab b where b.aar = #tab.aar and b.geoNr = #tab.geoNr and b.variabel = 'Utvandring')  
from #tab where geonr = '47' and variabel = 'Utflytting'


-- drop table #tab2,#tab3,#tab4,#tab5
select * into #tab2 from #tab
where variabel in (
--'Innenlandsk nettoinnflytting per 1 000 middelfolkemengde'
--,'Utvandring'
--,'Nettoinnflytting, innenlands'
'Innflytting'
--,'Nettoinnflytting per 1 000 middelfolkemengde'
,'Innvandring'
--,'Innflytting, innenlands'
,'Utflytting'
,'F�dselsoverskudd'
--,'Utflytting, innenlands'
,'Folkemengde'
,'Levendef�dte'
,'Invandrere'
--,'D�de'
--,'Netto inn- og utvandring per 1 000 middelfolkemengde'
--,'Nettoinnflytting'
--,'Nettoinnvandring'
,'Folketilvekst'
)




--select geonr,aar,count(*)  from #tab2 where variabel = 'Folkemengde' group by geonr, aar  order by 3 desc
-- drop table #tab3
select *, (select b.verdi from #tab2 b where b.geonr = a.geonr and a.aar = b.aar and b.variabel = 'Folkemengde' and verdi > 0  ) as Folkemengde 
into #tab3
from #tab2 a
---2:43 min 

select * from 

select * From KOMMUNESTRUKTUR_HIST_OG_FRAMTID_2019_mHist



select *,1000.0 * verdi / folkemengde as Rate1000 into #tab4 from #tab3



--select distinct variabel  from #tab4

-- drop table #tab5
select  *,
case variabel when  'Folketilvekst' then 1 
when 'Innvandring' then 2
	when				'Innflytting' then 3
	when				'Utflytting' then 4
	when	'F�dselsoverskudd' then 5 
	when	'Levendef�dte' then 6
	when	'Invandrere' then 7
--	when	'Folketilvekst' then 8
	when	'Folkemengde' then 8
	else 0 end as variabelID
	into #tab5
from #tab4

--select* from #tab5 where isnull(variabelid,0) = 0 

-- drop table #GeoSisetAktiveAAr
select geonr,geonamn,max(aar) SisteAktiveaar into #GeoSisetAktiveAAr from #tab5
where verdi > 0 
group by geonr,geonamn

--select * from #GeoSisetAktiveAAr 
--where SisteAktiveaar in (select max(SisteAktiveaar) from #GeoSisetAktiveAAr) 
--order by 1 

select * from Kommune_og_Fylke_HistoriskeStatusar

--select round(1.6,0),*    from #tab5 a
-- drop table #result 
select geonr,variabelID,aar,isnull(verdi,0) as  verdi,Rate1000  into #result  from #tab5 a
where geonr = '47' --  land uansett.. 
or (exists (selecT * from Kommune_og_Fylke_HistoriskeStatusar k where k.fylkenr= a.geonr and k.histstatus = 'Kommunar etter 1.1.2018' ))
or (exists (selecT * from Kommune_og_Fylke_HistoriskeStatusar k where k.komnr= a.geonr and k.histstatus = 'Kommunar etter 1.1.2018' )
  and exists (selecT * from #GeoSisetAktiveAAr k where k.geonr = a.geonr and k.geonamn = a.geonamn  ))
-- 25 sek 
-- (49825 row(s) affected)

select * from #result 

select geonr,variabelID,aar, count(*)  from #result 
group by geonr,variabelID,aar
having count(*) >1
--select len(geonr),substring(geonr,1,2),variabelID,aar,  sum(verdi) from #result 
select len(geonr),substring(geonr,1,2),variabel,aar,  sum(verdi) from #tab
where variabel in ('Folkemengde','Innvandring','Utvandring','D�de','Folkemengde','Folketilvekst','Invandrere','Nettoinnflytting','Levendef�dte')
group by substring(geonr,1,2),variabel,aar, len(geonr)

select len(geonr),substring(geonr,1,2),variabel,aar,  sum(verdi) from #tab
where variabel in ('Folkemengde','Innvandring','Utvandring','D�de','Folkemengde','Folketilvekst','Invandrere','Nettoinnflytting','Levendef�dte')
and len(geonr) = 2
group by substring(geonr,1,2),variabel,aar, len(geonr)

except 
select len(geonr),substring(geonr,1,2),variabel,aar,  sum(verdi) from #tab
where variabel in ('Folkemengde','Innvandring','Utvandring','D�de','Folkemengde','Folketilvekst','Invandrere','Nettoinnflytting','Levendef�dte')
and len(geonr) = 4
group by substring(geonr,1,2),variabel,aar, len(geonr)


order by substring(geonr,1,2), variabel, aar, len(geonr)


set nocount on
--- D015- BefolkningsEndringar
select * from #result 
where VariabelID in 
 (1, ---   'Folketilvekst' 
 2, -- Innvandring'
 3, -- 	'Innflytting' 
 4 ) -- 'Utflytting' 
--- til D015 -
---- lim inn 
--I:\system\Samhandlingsbarometeret\NesstarProsjekt\HFD_Innlesningsfiler\Demografi_SSB

 set nocount off 
---HUGS !!!  s�k og erstatt NULL med blanke !!! 
---- D016 f�dselsoverskot
select * from #result 
where VariabelID in 
 (5, -- 	'F�dselsoverskudd'
 6 --	'Levendef�dte'
 )  

 --- D017 invandrarar
select * from #result 
where VariabelID in 
 (7 -- -- 	'Invandrarar'
  )  


select * from #result  where geonr like '1431%'
and variabelid =  14

 = 'd�de'





