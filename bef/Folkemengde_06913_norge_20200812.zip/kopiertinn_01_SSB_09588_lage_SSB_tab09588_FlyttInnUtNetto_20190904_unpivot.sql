
select * from sysobjects order by crdate desc 
-- select * from SSB_tab09588_FlyttInnUtNetto_20170825_unpivot


drop table imp_SSB_09588_SAMLA_til_SQL_20190904_tab


select top 10 * from SSB_tab09588_FlyttInnUtNetto_20170825_unpivot where geonamn like '%norge%'
select top 10  *from imp2_SSB_09588_SAMLA_til_SQL_20190904_tab

-- drop table #t
select substring(geo,1,charindex(' ',geo)) geonr, ltrim(rtrim(substring(geo,charindex(' ',geo),200) ))as GeoNamn,
		substring(attributt,6,100) as variabel, substring(attributt,1,4) as aar, 
		converT(float,replacE(verdi,',','.')) as verdi into #t
		   from imp2_SSB_09588_SAMLA_til_SQL_20190904_tab

select * from #t where geonr like  '0 %' and GeoNamn like '%Hele landet%'
update #t set geonr = 47,geoNamn = 'Norge' where  geonr like  '0 %' and GeoNamn like '%Hele landet%'
-- 204 

select *from  ( 
select 'old' kilde,geonr,variabel,aar,verdi from SSB_tab09588_FlyttInnUtNetto_20170825_unpivot
except 
select 'old',geonr,variabel,aar,verdi from #t 
union 
select 'new',geonr,variabel,aar,verdi from #t 
except 
select 'new',geonr,variabel,aar,verdi from SSB_tab09588_FlyttInnUtNetto_20170825_unpivot
) a
where aar not in (2017,2018) 
and geonr not like '50%'
order by geonr,variabel,aar 


select * into SSB_tab09588_FlyttInnUtNetto_20190904_unpivot   from #T 


-- select *  into ##SSB_tab09588_tilKontroll   from SSB_tab09588_FlyttInnUtNetto_20190904_unpivot
create Proc  dwdoc_ssb_sjekk_SSB_TAB09588_kalkuleringsfeil
-- sjekk at det ikkje er nokon feil! 








